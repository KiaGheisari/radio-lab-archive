"""SDR Lab 01 recorder. Keep this source identical to the GRC embedded block.

Raw little-endian complex64: interleaved float32 I,Q, no header, 8 bytes/sample.
No files or directories are created while GRC inspects the constructor.
"""

import math
import re
import threading
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
from gnuradio import gr


class blk(gr.sync_block):
    """SDR Lab IQ Recorder: IDLE -> RECORDING -> WAIT until Record is cleared.

    Fc/Fs/Gain changes close the current file before accepting new settings.
    The sample limit and Fs used for duration are frozen at recording start.
    Use a normal flowgraph stop/window close so stop() can close the file.
    """

    def __init__(self, team='Team-00', lab=1, fc=100e6, fs=2.6e6,
                 gain=0.0, record=False, max_seconds=5.0, folder='.'):
        gr.sync_block.__init__(self, name='SDR Lab IQ Recorder',
                               in_sig=[np.complex64], out_sig=None)
        self._lock = threading.RLock()
        self.team = team
        self.lab = lab
        self.folder = folder
        self.max_seconds = max_seconds
        self._fc = fc
        self._fs = fs
        self._gain = gain
        self._record = bool(record)
        self._armed = True
        self._file = None
        self._session = None
        self._limit = 0
        self.samples_written = 0
        self.last_path = None
        self.last_reason = None

    @property
    def fc(self):
        return self._fc

    @fc.setter
    def fc(self, value):
        self._set_setting('fc', value)

    @property
    def fs(self):
        return self._fs

    @fs.setter
    def fs(self, value):
        self._set_setting('fs', value)

    @property
    def gain(self):
        return self._gain

    @gain.setter
    def gain(self, value):
        self._set_setting('gain', value)

    @property
    def record(self):
        return self._record

    @record.setter
    def record(self, value):
        with self._lock:
            self._record = bool(value)
            if not self._record:
                self._finish('record unchecked')
                self._armed = True

    def _set_setting(self, key, value):
        with self._lock:
            if value != getattr(self, '_' + key):
                self._finish(key + ' changed')
                setattr(self, '_' + key, value)

    def _begin(self):
        # Only work() starts recordings; property callbacks never open files.
        self._armed = False
        fc, fs, gain = float(self.fc), float(self.fs), float(self.gain)
        seconds = float(self.max_seconds)
        if not all(math.isfinite(v) for v in (fc, fs, gain, seconds)):
            raise ValueError('fc/fs/gain/max_seconds must be finite')
        if fs <= 0 or seconds < 0:
            raise ValueError('fs must be positive and max_seconds nonnegative')
        self._limit = math.floor(seconds * fs)
        self._session = (fc, fs, gain)
        self.samples_written = 0
        team = re.sub(r'[^A-Za-z0-9.-]+', '-', str(self.team)).strip('.') or 'Team-00'
        prefix = f'{team}_lab{int(self.lab):02d}_{int(round(fc))}_{int(round(fs))}_{gain:.1f}_'
        folder = Path(self.folder).expanduser()
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().replace(microsecond=0)
        collisions = 0
        while True:
            path = folder / (prefix + stamp.strftime('%Y%m%dT%H%M%S') + '.cf32')
            try:
                # Exclusive creation is atomic: never truncate an existing file.
                self._file = path.open('xb')
                break
            except FileExistsError:
                collisions += 1
                stamp += timedelta(seconds=1)
        self.last_path = str(path.resolve())
        self.last_reason = None
        if collisions:
            print('[REC] filename collision: advanced timestamp by '
                  f'{collisions} second(s), preserving standard filename', flush=True)
        print(f'[REC] start {path.name}', flush=True)
        if self._limit == 0:
            self._finish('max_seconds reached')

    def _finish(self, reason):
        if self._file is None:
            return
        stream, self._file = self._file, None
        self._armed = False
        self.last_reason = reason
        try:
            stream.close()
        finally:
            seconds = self.samples_written / self._session[1]
            print(f'[REC] stop {self.samples_written} samples = {seconds:.9f} s '
                  f'({reason})', flush=True)

    def work(self, input_items, output_items):
        samples = input_items[0]
        with self._lock:
            try:
                if self.record and self._armed and len(samples):
                    self._begin()
                if self._file is not None:
                    count = min(len(samples), self._limit - self.samples_written)
                    if count:
                        # One array write, with the final buffer cropped exactly.
                        np.asarray(samples[:count], dtype='<c8').tofile(self._file)
                        self.samples_written += count
                    if self.samples_written == self._limit:
                        self._finish('max_seconds reached')
            except (OSError, ValueError, OverflowError) as error:
                self._armed = False
                self._finish('recording error')
                print(f'[REC] error {type(error).__name__}: {error}; '
                      'clear Record before retrying', flush=True)
        # sync_block consumes the whole input even if nothing was saved.
        return len(samples)

    def stop(self):
        with self._lock:
            self._finish('flowgraph stopped')
            self._armed = False
        return True
